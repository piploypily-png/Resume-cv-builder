// Vercel serverless function: AI Fill (mode "fill") and AI Edit (mode "edit") using the Claude API.
// Set ANTHROPIC_API_KEY in Vercel > Project > Settings > Environment Variables, then redeploy.
async function ask(prompt, key) {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
    body: JSON.stringify({ model: 'claude-sonnet-5-5', max_tokens: 4096, messages: [{ role: 'user', content: prompt }] })
  });
  const data = await r.json();
  if (!r.ok) throw { status: 502, message: (data.error && data.error.message) || 'API error' };
  const text = (data.content || []).map(c => c.text || '').join('');
  const i = text.indexOf('{'), j = text.lastIndexOf('}');
  if (i < 0 || j < i) throw { status: 502, message: 'AI did not return CV data' + (data.stop_reason === 'max_tokens' ? ' (response too long)' : '') };
  try { return JSON.parse(text.slice(i, j + 1)); }
  catch (e) { throw { status: 500, message: 'Could not read AI response: ' + e.message }; }
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return res.status(500).json({ error: 'Missing ANTHROPIC_API_KEY' });
  const body = req.body || {};
  try {
    if (body.mode === 'edit') {
      const instruction = String(body.instruction || '').slice(0, 1500).trim();
      const cv = JSON.stringify(body.cv || {}).slice(0, 20000);
      if (!instruction) return res.status(400).json({ error: 'Empty instruction' });
      const prompt = `You are a CV editing assistant. Apply the user's instruction to the CV JSON below. Rules: change only what the instruction asks for; never invent facts, employers, dates, numbers, links or skills; keep the CV's language unless asked to translate; keep the order and number of projects. Reply with JSON only (no markdown): {"message":"one or two short sentences saying what you changed, or a short answer if it was only a question","cv":{the FULL updated CV in the same shape}}. Write "message" in the language of the instruction. If nothing needs changing, return the cv unchanged.
CV: ${cv}
INSTRUCTION: ${instruction}`;
      return res.status(200).json(await ask(prompt, key));
    }
    const raw = String(body.raw || '').slice(0, 8000);
    if (!raw.trim()) return res.status(400).json({ error: 'Empty input' });
    const prompt = `You fill in a CV from raw text. Extract and lightly polish (concise, action-led bullets, no invented facts or numbers). Reply with JSON only, no markdown, using this shape and omitting nothing you can fill:
{"name":"","title":"","summary":"1-2 sentences","email":"","phone":"","city":"","site":"","skills":["..."],"exp":[{"role":"","company":"","from":"YYYY","to":"YYYY or Now","city":"","bullets":["..."]}],"edu":[{"degree":"","school":"","year":"","note":""}],"projects":[{"name":"","link":"","desc":""}]}
Use the same language as the raw text. Max 12 skills, 4 bullets per role. Most recent role first.
RAW TEXT:
${raw}`;
    return res.status(200).json(await ask(prompt, key));
  } catch (e) {
    return res.status(e.status || 500).json({ error: e.message || 'Unknown error' });
  }
};

# CV Builder (Vercel)
- index.html  -> the app
- api/fill.js -> AI Fill backend (keeps your API key private)
Deploy: push this folder to GitHub -> Vercel "Add New Project" -> import it.
Then add env var ANTHROPIC_API_KEY (from console.anthropic.com) and redeploy.
